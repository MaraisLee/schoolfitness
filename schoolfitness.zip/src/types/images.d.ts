declare module '*.png';
declare module '*.gif';
declare module '*.jpg';
