export const orangeColor = '#FF8339';
